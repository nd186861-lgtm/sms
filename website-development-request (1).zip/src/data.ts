
import { Notice, StudentProfile, User } from './types';

export const mockNotices: Notice[] = [
  {
    id: '1',
    title: 'Final Examination Schedule',
    content: 'The final exams will start from June 15th. Please check the timetable.',
    date: '2024-05-20',
    category: 'academic',
  },
  {
    id: '2',
    title: 'Annual Sports Meet 2024',
    content: 'Register now for the upcoming sports events scheduled for next month.',
    date: '2024-05-18',
    category: 'event',
  },
  {
    id: '3',
    title: 'Library Books Return',
    content: 'Please return all borrowed books by the end of this week to avoid fines.',
    date: '2024-05-15',
    category: 'urgent',
  },
];

export const mockStudent: StudentProfile = {
  id: 's1',
  username: 'sharath',
  name: 'Sharath Kumar',
  role: 'student',
  studentId: 'STU2024001',
  class: '10th Grade - A',
  email: 'sharath@example.com',
  phone: '+1 234 567 890',
  grades: [
    { subject: 'Mathematics', score: 92, total: 100, grade: 'A+' },
    { subject: 'Science', score: 88, total: 100, grade: 'A' },
    { subject: 'English', score: 95, total: 100, grade: 'A+' },
    { subject: 'History', score: 82, total: 100, grade: 'B+' },
  ],
};

export const mockAdmin: User = {
  id: 'a1',
  username: 'admin',
  name: 'Administrator',
  role: 'admin',
};

export const allUsers: User[] = [
  { id: '1', username: 'admin', name: 'Admin', role: 'admin' },
  { id: '2', username: 'sharath', name: 'Sharath', role: 'student' },
  { id: '3', username: 'ankesh', name: 'Ankesh', role: 'student' },
];
