
import React, { useState } from 'react';
import { 
  Bell, 
  BookOpen, 
  Calendar, 
  GraduationCap, 
  LogOut, 
  MessageSquare, 
  Settings, 
  User as UserIcon,
  TrendingUp,
  CheckCircle2,
  Menu,
  X
} from 'lucide-react';
import { mockStudent, mockNotices } from '../data';
import { cn } from '../lib/utils';

interface StudentDashboardProps {
  onLogout: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ onLogout }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 w-64 bg-white border-r border-slate-200 flex flex-col z-50 transition-transform lg:translate-x-0 lg:static lg:inset-0",
        isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-6">
          <div className="flex items-center gap-3 text-indigo-600 mb-8">
            <div className="p-2 bg-indigo-600 rounded-lg text-white">
              <GraduationCap size={24} />
            </div>
            <span className="font-bold text-xl text-slate-900">EduManage</span>
          </div>
          <button 
            onClick={() => setIsMobileMenuOpen(false)}
            className="absolute top-6 right-6 p-2 text-slate-500 hover:bg-slate-100 rounded-lg lg:hidden"
          >
            <X size={20} />
          </button>

          <nav className="space-y-1">
            <NavItem icon={<LayoutDashboard size={20} />} label="Dashboard" active />
            <NavItem icon={<BookOpen size={20} />} label="My Courses" />
            <NavItem icon={<Calendar size={20} />} label="Schedule" />
            <NavItem icon={<TrendingUp size={20} />} label="Grades" />
            <NavItem icon={<Bell size={20} />} label="Notices" />
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-slate-100">
          <nav className="space-y-1">
            <NavItem icon={<Settings size={20} />} label="Settings" />
            <button 
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-3 py-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors group"
            >
              <LogOut size={20} className="group-hover:text-red-600" />
              <span className="font-medium">Logout</span>
            </button>
          </nav>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-20 bg-white border-b border-slate-200 px-4 lg:px-8 flex items-center justify-between">
          <div className="flex items-center">
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg lg:hidden mr-4"
            >
              <Menu size={24} />
            </button>
            <div>
              <h2 className="text-lg lg:text-xl font-bold text-slate-900 line-clamp-1">Welcome back, {mockStudent.name}!</h2>
              <p className="text-xs lg:text-sm text-slate-500">{mockStudent.class} • {mockStudent.studentId}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-slate-400 hover:text-indigo-600 transition-colors">
              <Bell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
              <div className="text-right">
                <p className="text-sm font-bold text-slate-900">{mockStudent.name}</p>
                <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">Student</p>
              </div>
              <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600">
                <UserIcon size={20} />
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Stats and Notices */}
            <div className="lg:col-span-2 space-y-8">
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard 
                  label="GPA" 
                  value="3.8" 
                  icon={<TrendingUp className="text-emerald-600" size={24} />}
                  color="emerald"
                />
                <StatCard 
                  label="Attendance" 
                  value="94%" 
                  icon={<CheckCircle2 className="text-blue-600" size={24} />}
                  color="blue"
                />
                <StatCard 
                  label="Total Credits" 
                  value="24" 
                  icon={<BookOpen className="text-indigo-600" size={24} />}
                  color="indigo"
                />
              </div>

              {/* Grades Table */}
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="font-bold text-slate-900">Academic Performance</h3>
                  <button className="text-indigo-600 text-sm font-bold hover:underline">View All</button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-slate-50">
                        <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Subject</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Score</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Total</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Grade</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {mockStudent.grades.map((g, i) => (
                        <tr key={i} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-4 font-medium text-slate-900">{g.subject}</td>
                          <td className="px-6 py-4 text-slate-600">{g.score}</td>
                          <td className="px-6 py-4 text-slate-600">{g.total}</td>
                          <td className="px-6 py-4 text-right font-bold text-indigo-600">{g.grade}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Right Column - Notices & Messages */}
            <div className="space-y-8">
              {/* Notices */}
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="font-bold text-slate-900">Recent Notices</h3>
                  <Bell className="text-slate-400" size={20} />
                </div>
                <div className="p-6 space-y-6">
                  {mockNotices.map((notice) => (
                    <div key={notice.id} className="group cursor-pointer">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={cn(
                          "w-2 h-2 rounded-full",
                          notice.category === 'urgent' ? "bg-red-500" : 
                          notice.category === 'academic' ? "bg-indigo-500" : "bg-blue-500"
                        )}></span>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{notice.date}</span>
                      </div>
                      <h4 className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">{notice.title}</h4>
                      <p className="text-sm text-slate-500 line-clamp-2 mt-1">{notice.content}</p>
                    </div>
                  ))}
                  <button className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-sm font-bold transition-all">
                    Show All Notices
                  </button>
                </div>
              </div>

              {/* Quick Contact */}
              <div className="bg-indigo-600 rounded-2xl p-6 text-white">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-indigo-500 rounded-lg">
                    <MessageSquare size={20} />
                  </div>
                  <h3 className="font-bold">Need Help?</h3>
                </div>
                <p className="text-indigo-100 text-sm mb-6">Contact your counselor or the admin desk for any queries.</p>
                <button className="w-full py-3 bg-white text-indigo-600 rounded-xl text-sm font-bold shadow-lg shadow-indigo-900/20 active:scale-95 transition-all">
                  Contact Support
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

// Helper Components
const NavItem = ({ icon, label, active = false }: { icon: React.ReactNode, label: string, active?: boolean }) => (
  <button className={cn(
    "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all font-medium",
    active 
      ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200" 
      : "text-slate-500 hover:text-indigo-600 hover:bg-indigo-50"
  )}>
    {icon}
    <span>{label}</span>
  </button>
);

const StatCard = ({ label, value, icon, color }: { label: string, value: string, icon: React.ReactNode, color: string }) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 flex items-center justify-between">
    <div>
      <p className="text-sm font-medium text-slate-500 mb-1">{label}</p>
      <h3 className="text-2xl font-bold text-slate-900">{value}</h3>
    </div>
    <div className={cn(
      "p-3 rounded-xl",
      color === 'emerald' ? "bg-emerald-50" : color === 'blue' ? "bg-blue-50" : "bg-indigo-50"
    )}>
      {icon}
    </div>
  </div>
);

const LayoutDashboard = ({ size }: { size: number }) => <TrendingUp size={size} />;
