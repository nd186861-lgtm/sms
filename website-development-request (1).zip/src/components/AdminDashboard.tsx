
import React, { useState } from 'react';
import { 
  Users, 
  GraduationCap, 
  Bell, 
  Search, 
  Plus, 
  MoreVertical, 
  LogOut, 
  LayoutDashboard,
  Settings,
  Mail,
  Filter,
  Menu,
  X
} from 'lucide-react';
import { cn } from '../lib/utils';
import { allUsers } from '../data';

interface AdminDashboardProps {
  onLogout: () => void;
}



export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 w-64 bg-white border-r border-slate-200 flex flex-col z-50 transition-transform lg:translate-x-0 lg:static lg:inset-0",
        isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-6">
          <div className="flex items-center gap-3 text-indigo-600 mb-8">
            <div className="p-2 bg-indigo-600 rounded-lg text-white">
              <GraduationCap size={24} />
            </div>
            <span className="font-bold text-xl text-slate-900">EduAdmin</span>
          </div>
          <button 
            onClick={() => setIsMobileMenuOpen(false)}
            className="absolute top-6 right-6 p-2 text-slate-500 hover:bg-slate-100 rounded-lg lg:hidden"
          >
            <X size={20} />
          </button>

          <nav className="space-y-1">
            <NavItem icon={<LayoutDashboard size={20} />} label="Overview" active />
            <NavItem icon={<Users size={20} />} label="Students" />
            <NavItem icon={<GraduationCap size={20} />} label="Teachers" />
            <NavItem icon={<Bell size={20} />} label="Announcements" />
            <NavItem icon={<Mail size={20} />} label="Messages" />
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-slate-100">
          <nav className="space-y-1">
            <NavItem icon={<Settings size={20} />} label="Admin Settings" />
            <button 
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-3 py-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors group"
            >
              <LogOut size={20} className="group-hover:text-red-600" />
              <span className="font-medium">Logout</span>
            </button>
          </nav>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-20 bg-white border-b border-slate-200 px-4 lg:px-8 flex items-center justify-between">
          <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg lg:hidden mr-2"
          >
            <Menu size={24} />
          </button>
          <div className="flex items-center gap-4 bg-slate-100 px-4 py-2.5 rounded-xl w-full max-w-md">
            <Search size={18} className="text-slate-400" />
            <input 
              type="text" 
              placeholder="Search students, staff, or documents..." 
              className="bg-transparent border-none focus:ring-0 text-sm w-full"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-4">
            <button className="p-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors flex items-center gap-2">
              <Plus size={18} />
              <span className="text-sm font-bold">New Admission</span>
            </button>
            <div className="w-px h-8 bg-slate-200 mx-2"></div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-sm font-bold text-slate-900">System Admin</p>
                <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest text-right">Superuser</p>
              </div>
              <div className="w-10 h-10 bg-slate-900 rounded-full flex items-center justify-center text-white">
                <Settings size={20} />
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Student Directory</h1>
              <p className="text-slate-500">Manage all registered students in the system.</p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-50">
              <Filter size={18} />
              Filters
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <QuickStat label="Total Students" value="1,284" sub="+12 this month" color="indigo" />
            <QuickStat label="Active Classes" value="48" sub="Across all grades" color="emerald" />
            <QuickStat label="Staff Members" value="64" sub="Teaching & Support" color="blue" />
            <QuickStat label="Pending Apps" value="15" sub="Review required" color="orange" />
          </div>

          {/* Users Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">User</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">ID</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Role</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {allUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-indigo-600 font-bold text-xs">
                          {user.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-medium text-slate-900">{user.name}</p>
                          <p className="text-xs text-slate-500">{user.username}@edu.com</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">#{1000 + parseInt(user.id)}</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                        user.role === 'admin' ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
                      )}>
                        {user.role}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                        <span className="text-sm text-slate-600">Active</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-slate-400 hover:text-slate-600 p-1">
                        <MoreVertical size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="p-4 border-t border-slate-100 flex items-center justify-between text-sm text-slate-500">
              <p>Showing 1 to {allUsers.length} of 1,284 entries</p>
              <div className="flex gap-2">
                <button className="px-3 py-1 border border-slate-200 rounded hover:bg-slate-50 disabled:opacity-50">Previous</button>
                <button className="px-3 py-1 border border-slate-200 rounded bg-indigo-600 text-white">1</button>
                <button className="px-3 py-1 border border-slate-200 rounded hover:bg-slate-50">2</button>
                <button className="px-3 py-1 border border-slate-200 rounded hover:bg-slate-50">Next</button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

// Helper Components
const NavItem = ({ icon, label, active = false }: { icon: React.ReactNode, label: string, active?: boolean }) => (
  <button className={cn(
    "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all font-medium",
    active 
      ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200" 
      : "text-slate-500 hover:text-indigo-600 hover:bg-indigo-50"
  )}>
    {icon}
    <span>{label}</span>
  </button>
);

const QuickStat = ({ label, value, sub, color }: { label: string, value: string, sub: string, color: string }) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200">
    <p className="text-sm font-medium text-slate-500 mb-1">{label}</p>
    <h3 className="text-2xl font-bold text-slate-900 mb-2">{value}</h3>
    <p className={cn(
      "text-[10px] font-bold uppercase tracking-wider",
      color === 'indigo' ? "text-indigo-600" : color === 'emerald' ? "text-emerald-600" : color === 'blue' ? "text-blue-600" : "text-orange-600"
    )}>
      {sub}
    </p>
  </div>
);
