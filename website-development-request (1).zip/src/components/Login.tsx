
import React, { useState } from 'react';
import { User, Lock, Eye, EyeOff, GraduationCap, LayoutDashboard, UserCheck } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '../lib/utils';
import { UserRole } from '../types';

interface LoginProps {
  onLogin: (username: string, role: UserRole) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [activeTab, setActiveTab] = useState<'signin' | 'register'>('signin');
  const [role, setRole] = useState<UserRole>('student');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      onLogin(username, role);
    }
  };

  const fillDemo = (u: string, p: string, r: UserRole) => {
    setUsername(u);
    setPassword(p);
    setRole(r);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="inline-flex items-center justify-center p-3 bg-indigo-600 rounded-2xl text-white mb-4 shadow-lg shadow-indigo-200">
          <GraduationCap size={32} />
        </div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Student Management System</h1>
        <p className="text-slate-500 mt-2 max-w-sm mx-auto">
          Manage profiles, classes, notices, and grades in a unified, modern workspace.
        </p>
      </motion.div>

      {/* Login Card */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-3xl shadow-xl shadow-indigo-100/50 w-full max-w-md p-8 border border-slate-100"
      >
        {/* Tabs */}
        <div className="flex bg-slate-100 p-1 rounded-xl mb-8">
          <button
            onClick={() => setActiveTab('signin')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-lg transition-all",
              activeTab === 'signin' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
            )}
          >
            <UserCheck size={18} />
            Sign In
          </button>
          <button
            onClick={() => setActiveTab('register')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-lg transition-all",
              activeTab === 'register' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
            )}
          >
            <User size={18} />
            Register Student
          </button>
        </div>

        {/* Portal Access Toggle */}
        <div className="mb-6">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 block">Portal Access</label>
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setRole('student')}
              className={cn(
                "flex items-center justify-center gap-2 py-3 border-2 rounded-xl transition-all",
                role === 'student' 
                  ? "border-indigo-600 bg-indigo-50 text-indigo-600" 
                  : "border-slate-100 text-slate-500 hover:border-slate-200"
              )}
            >
              <User size={18} />
              <span className="font-medium">Student Panel</span>
            </button>
            <button
              onClick={() => setRole('admin')}
              className={cn(
                "flex items-center justify-center gap-2 py-3 border-2 rounded-xl transition-all",
                role === 'admin' 
                  ? "border-indigo-600 bg-indigo-50 text-indigo-600" 
                  : "border-slate-100 text-slate-500 hover:border-slate-200"
              )}
            >
              <GraduationCap size={18} />
              <span className="font-medium">Admin Panel</span>
            </button>
          </div>
        </div>

        {/* Form */}
        {activeTab === 'signin' ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-slate-700 mb-1.5 block">Username</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. anujk3"
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 mb-1.5 block">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-12 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-indigo-200 active:scale-[0.98]"
            >
              Access Portal
            </button>
          </form>
        ) : (
          <div className="py-12 text-center">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
              <User size={32} />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Registration Closed</h3>
            <p className="text-slate-500 text-sm px-8">
              New student registration is currently handled by the administration office. Please contact them for enrollment.
            </p>
            <button 
              onClick={() => setActiveTab('signin')}
              className="mt-6 text-indigo-600 font-bold text-sm hover:underline"
            >
              Back to Sign In
            </button>
          </div>
        )}

        {/* Demo Credentials */}
        <div className="mt-10">
          <div className="flex items-center gap-2 text-indigo-600 text-xs font-bold uppercase tracking-wider mb-4">
            <LayoutDashboard size={14} />
            Click to auto-fill demo credentials
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => fillDemo('admin', 'admin', 'admin')}
              className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-left hover:border-indigo-200 transition-all group"
            >
              <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">Admin Panel</p>
              <p className="text-[10px] text-slate-500">User: admin</p>
              <p className="text-[10px] text-slate-500">Pass: admin</p>
            </button>
            <button
              onClick={() => fillDemo('sharath', 'sharath', 'student')}
              className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-left hover:border-indigo-200 transition-all group"
            >
              <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">Student (Sharath)</p>
              <p className="text-[10px] text-slate-500">User: sharath</p>
              <p className="text-[10px] text-slate-500">Pass: sharath</p>
            </button>
            <button
              onClick={() => fillDemo('ankesh', 'ankesh', 'student')}
              className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-left hover:border-indigo-200 transition-all group"
            >
              <p className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">Student (Ankesh)</p>
              <p className="text-[10px] text-slate-500">User: ankesh</p>
              <p className="text-[10px] text-slate-500">Pass: ankesh</p>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
