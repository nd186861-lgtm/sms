
export type UserRole = 'student' | 'admin';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  avatar?: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  date: string;
  category: 'academic' | 'event' | 'urgent';
}

export interface Grade {
  subject: string;
  score: number;
  total: number;
  grade: string;
}

export interface StudentProfile extends User {
  studentId: string;
  class: string;
  email: string;
  phone: string;
  grades: Grade[];
}
